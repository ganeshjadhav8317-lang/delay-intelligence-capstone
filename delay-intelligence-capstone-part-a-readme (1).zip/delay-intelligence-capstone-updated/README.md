# Delay Intelligence Capstone

## Part A — Data cleaning, exploratory analysis, and delay evidence

Run the complete Part A pipeline from the repository root:

```bash
pip install -r requirements.txt
python generate_data.py
python part_a_clean_eda.py
```

The pipeline cleans the historical shipment data, builds the modelling table, computes data-quality checks, and writes the delay evidence and numeric correlation matrix under `outputs/`.

### Data findings

The following findings are calculated from the generated Part A output files (`outputs/part_a_delay_by_group.csv`, `outputs/part_a_correlations.csv`, and `outputs/part_a_checks.csv`).

1. **Service type:** Express shipments have the highest delay rate at **0.4897 (48.97%)**, compared with Standard at 0.2056 and Economy at 0.0857.

2. **Hub operating tier:** The delay rate rises from **0.0400 (4.00%) in Tier 1** to **0.2150 (21.50%) in Tier 2** and **0.4400 (44.00%) in Tier 3**. This is a 40.00 percentage-point increase from Tier 1 to Tier 3.

3. **Distance band:** Delay rate increases with distance: **0.0219 (2.19%)** for 0–200 km, **0.1368 (13.68%)** for 201–400 km, **0.4364 (43.64%)** for 401–600 km, and **0.8523 (85.23%)** for 601+ km.

4. **Strongest correlations with delivery time:** Ranking the numeric columns by absolute Pearson correlation with `delivery_hours` (excluding `delivery_hours` itself), the top three are **`promised_hours` (+0.8372)**, **`distance_km` (+0.4013)**, and **`n_stops` (+0.3247)**. These are associations in this dataset and should not be interpreted as proof of causation.

5. **Why log-transform declared value:** In the filled modelling column, `declared_value_inr` has a mean of **₹1,533.0542** and median of **₹1,121.5000**, indicating a mean pulled above the median by higher values; after the natural-log transformation, the mean and median are much closer at **7.0277** and **7.0224**, respectively, so the transformation reduces the influence of the long right tail and makes the distribution less skewed.

### Generated outputs

- `data/modelling_table.csv` — cleaned, feature-engineered modelling dataset with the delay target.
- `outputs/part_a_checks.csv` — cleaning, missing-value, target, and distribution checks.
- `outputs/part_a_delay_by_group.csv` — shipment counts, delayed counts, delay rates, and mean delivery hours by service type, hub tier, and distance band.
- `outputs/part_a_correlations.csv` — Pearson correlation matrix for numeric modelling-table columns; the first column stores the row labels.

### Notes

- The delay target is defined as `delivery_hours > promised_hours`.
- The distance bands use cut edges `[0, 200, 400, 600, 2000]`, right-inclusive intervals, and labels `0-200`, `201-400`, `401-600`, and `601+`.
- Correlation describes linear association, not causation.
